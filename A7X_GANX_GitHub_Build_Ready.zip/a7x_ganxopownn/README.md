# A7X // GANX

Flutter project for an Avenged Sevenfold-inspired dark utility app branded **GanXopownn**.

## Build

1. Install Flutter 3.x and Android Studio.
2. From this directory run:
   ```bash
   flutter pub get
   flutter build apk --release
   ```
3. The APK will be generated under:
   `build/app/outputs/flutter-apk/app-release.apk`

## Notes

- The interface is intentionally compact and dark, with red/black heavy-metal styling.
- The utility actions are non-destructive.
- No external Flutter packages are required.