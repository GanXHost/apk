package com.ganxopownn.a7xganx

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()