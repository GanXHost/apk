# Build APK langsung dari HP

1. Buat akun/login GitHub.
2. Buat repository baru, misalnya `a7x-ganx`.
3. Upload SEMUA isi project ini ke repository.
4. Masuk tab **Actions**.
5. Pilih workflow **Build A7X GANX APK**.
6. Tekan **Run workflow**.
7. Tunggu sampai job selesai dengan tanda centang hijau.
8. Buka hasil workflow tersebut dan cari bagian **Artifacts**.
9. Download `A7X-GANX-release`.
10. Extract ZIP-nya. Di dalamnya ada `app-release.apk`.
11. Install APK di Android 13.

Kalau Actions meminta permission pertama kali, izinkan workflow untuk repository tersebut.

Catatan:
- Jangan upload ke repository publik kalau project berisi hal yang tidak ingin dibagikan.
- APK ini hanya berisi fungsi utility yang aman.