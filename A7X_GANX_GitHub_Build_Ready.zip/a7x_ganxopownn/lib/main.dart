import 'dart:io';
import 'package:flutter/material.dart';

void main() => runApp(const GanxA7XApp());

class GanxA7XApp extends StatelessWidget {
  const GanxA7XApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'A7X // GANX',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF080808),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFE52B2B),
          brightness: Brightness.dark,
        ),
        fontFamily: 'monospace',
        useMaterial3: true,
      ),
      home: const Shell(),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int index = 0;

  final pages = const [
    HomePage(),
    ToolsPage(),
    AboutPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        backgroundColor: const Color(0xFF0D0D0D),
        indicatorColor: const Color(0x33E52B2B),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), selectedIcon: Icon(Icons.grid_view), label: 'Tools'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'About'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
      children: [
        Row(
          children: [
            const Expanded(
              child: Text(
                'A7X // GANX',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, letterSpacing: 2.4),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
              decoration: BoxDecoration(
                border: Border.all(color: const Color(0xFF3A3A3A)),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text('01', style: TextStyle(color: Color(0xFFE52B2B), fontWeight: FontWeight.bold)),
            ),
          ],
        ),
        const SizedBox(height: 18),
        Container(
          height: 230,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF251010), Color(0xFF0C0C0C), Color(0xFF180A0A)],
            ),
            border: Border.all(color: const Color(0xFF3A1B1B)),
          ),
          child: Stack(
            children: [
              Positioned(
                right: -45,
                top: -55,
                child: Transform.rotate(
                  angle: -0.35,
                  child: Icon(Icons.bolt, size: 280, color: const Color(0xFFE52B2B).withOpacity(.09)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('AVENGED SEVENFOLD',
                        style: TextStyle(fontSize: 12, letterSpacing: 3.5, color: Color(0xFFBDBDBD))),
                    const Spacer(),
                    const Text('NIGHT//SHIFT',
                        style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                    const SizedBox(height: 7),
                    const Text('Tools built with a darker edge.',
                        style: TextStyle(color: Color(0xFF9A9A9A), fontSize: 14)),
                    const SizedBox(height: 18),
                    Container(height: 3, width: 74, color: const Color(0xFFE52B2B)),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        const SectionTitle('QUICK ACCESS'),
        const SizedBox(height: 10),
        Row(
          children: const [
            Expanded(child: QuickCard(icon: Icons.wifi_tethering, title: 'Connection', subtitle: 'Check internet')),
            SizedBox(width: 10),
            Expanded(child: QuickCard(icon: Icons.bolt, title: 'Utilities', subtitle: 'Fast tools')),
          ],
        ),
        const SizedBox(height: 18),
        const SectionTitle('DEVELOPER'),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF101010),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFF252525)),
          ),
          child: const Row(
            children: [
              CircleAvatar(
                radius: 23,
                backgroundColor: Color(0xFFE52B2B),
                child: Icon(Icons.code, color: Colors.white),
              ),
              SizedBox(width: 13),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('GanXopownn', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  SizedBox(height: 3),
                  Text('Independent developer', style: TextStyle(color: Color(0xFF888888), fontSize: 12)),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class QuickCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const QuickCard({super.key, required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFF101010),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF242424)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: const Color(0xFFE52B2B), size: 23),
          const SizedBox(height: 16),
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 3),
          Text(subtitle, style: const TextStyle(color: Color(0xFF777777), fontSize: 11)),
        ],
      ),
    );
  }
}

class ToolsPage extends StatefulWidget {
  const ToolsPage({super.key});
  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> {
  String status = 'READY';
  bool busy = false;

  Future<void> checkConnection() async {
    setState(() {
      busy = true;
      status = 'CHECKING';
    });
    try {
      final client = HttpClient()..connectionTimeout = const Duration(seconds: 5);
      final request = await client.getUrl(Uri.parse('https://example.com'));
      final response = await request.close();
      client.close();
      setState(() => status = response.statusCode == 200 ? 'ONLINE' : 'HTTP ${response.statusCode}');
    } catch (_) {
      setState(() => status = 'OFFLINE');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void showInfo(String title, String body) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF111111),
      showDragHandle: true,
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 5, 20, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text(body, style: const TextStyle(color: Color(0xFFAAAAAA), height: 1.5)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
      children: [
        const Text('TOOLS', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900, letterSpacing: 2)),
        const SizedBox(height: 5),
        const Text('UTILITY PANEL', style: TextStyle(color: Color(0xFF777777), letterSpacing: 2)),
        const SizedBox(height: 22),
        ToolTile(
          icon: Icons.wifi_tethering,
          title: 'CONNECTION CHECK',
          subtitle: status,
          trailing: busy ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : null,
          onTap: checkConnection,
        ),
        ToolTile(
          icon: Icons.devices_other,
          title: 'DEVICE STATUS',
          subtitle: 'Basic runtime information',
          onTap: () => showInfo('Device Status', 'Platform: ${Platform.operatingSystem}\nDart: ${Platform.version.split(' ').first}'),
        ),
        ToolTile(
          icon: Icons.flash_on,
          title: 'QUICK ACTION',
          subtitle: 'Fast utility panel',
          onTap: () => showInfo('Quick Action', 'Your utility panel is ready. Add your own safe shortcuts here.'),
        ),
        ToolTile(
          icon: Icons.info_outline,
          title: 'ABOUT BUILD',
          subtitle: 'A7X // GANX',
          onTap: () => showInfo('A7X // GANX', 'Built by GanXopownn with a dark, compact utility-first interface.'),
        ),
      ],
    );
  }
}

class ToolTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget? trailing;
  final VoidCallback onTap;
  const ToolTile({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 11),
      decoration: BoxDecoration(
        color: const Color(0xFF101010),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF242424)),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
        leading: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: const Color(0x19E52B2B),
            borderRadius: BorderRadius.circular(11),
          ),
          child: Icon(icon, color: const Color(0xFFE52B2B)),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13, letterSpacing: .8)),
        subtitle: Text(subtitle, style: const TextStyle(color: Color(0xFF777777), fontSize: 11)),
        trailing: trailing ?? const Icon(Icons.chevron_right, color: Color(0xFF555555)),
        onTap: onTap,
      ),
    );
  }
}

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 28),
      children: [
        const Text('ABOUT', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900, letterSpacing: 2)),
        const SizedBox(height: 22),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: const Color(0xFF101010),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFF2A2A2A)),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('A7X // GANX', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
              SizedBox(height: 8),
              Text('AVENGED SEVENFOLD INSPIRED UI', style: TextStyle(color: Color(0xFFE52B2B), fontSize: 11, letterSpacing: 2)),
              SizedBox(height: 22),
              Divider(color: Color(0xFF292929)),
              SizedBox(height: 18),
              Text('DEVELOPER', style: TextStyle(color: Color(0xFF777777), fontSize: 11, letterSpacing: 2)),
              SizedBox(height: 6),
              Text('GanXopownn', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              SizedBox(height: 20),
              Text('A compact dark utility interface with a heavy-metal visual direction and practical, non-destructive tools.',
                  style: TextStyle(color: Color(0xFF9A9A9A), height: 1.55)),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: const Color(0xFF0E0E0E),
            border: Border.all(color: const Color(0xFF242424)),
          ),
          child: const Row(
            children: [
              Icon(Icons.local_fire_department, color: Color(0xFFE52B2B)),
              SizedBox(width: 10),
              Expanded(child: Text('Built to look sharp first. No clutter, no fake sci-fi overload.', style: TextStyle(color: Color(0xFF8E8E8E)))),
            ],
          ),
        ),
      ],
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Text(text, style: const TextStyle(color: Color(0xFF777777), fontSize: 11, letterSpacing: 2.5, fontWeight: FontWeight.bold));
}